import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [activeTab, setActiveTab] = useState('jobs');

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  useEffect(() => {
    // 獲取職缺列表
    axios.get('https://musical-lamp-jjxw79wqjjx925jpx-5000.app.github.dev/api/jobs')
      .then(res => setJobs(res.data))
      .catch(err => console.error('Failed to fetch jobs:', err));
  }, []);

  // 求職者導航項目
  const jobSeekerNav = [
    { id: 'jobs', label: '找工作', icon: '🔍' },
    { id: 'notifications', label: '通知', icon: '🔔' },
    { id: 'resume', label: '履歷表', icon: '📄' },
    { id: 'forum', label: '論壇', icon: '💬' },
    { id: 'settings', label: '設定', icon: '⚙️' },
  ];

  // 雇主導航項目
  const employerNav = [
    { id: 'post-job', label: '發布職缺', icon: '📝' },
    { id: 'applications', label: '查看應徵', icon: '👥' },
    { id: 'forum', label: '論壇', icon: '💬' },
    { id: 'settings', label: '設定', icon: '⚙️' },
  ];

  const navItems = user?.role === 'employer' ? employerNav : jobSeekerNav;

  const handleNavClick = (navId) => {
    if (navId === 'jobs' || navId === 'notifications' || navId === 'resume' ||
        navId === 'forum' || navId === 'settings') {
      navigate(`/dashboard?tab=${navId}`);
    } else {
      navigate(`/${navId}`);
    }
    setActiveTab(navId);
  };

  // 渲染當前 tab 內容
  const renderContent = () => {
    switch (activeTab) {
      case 'jobs':
        return (
          <div>
            <h2 style={{ fontSize: '1.5rem', marginBottom: 20 }}>職缺列表</h2>
            {jobs.length === 0 ? (
              <p style={{ color: '#666' }}>目前沒有職缺</p>
            ) : (
              jobs.map(job => (
                <div key={job._id} style={{
                  border: '1px solid #ddd',
                  padding: 16,
                  margin: '10px 0',
                  borderRadius: 8,
                  backgroundColor: 'white'
                }}>
                  <h3 style={{ color: '#667eea' }}>{job.title}</h3>
                  <p style={{ fontWeight: 'bold' }}>{job.company?.companyName}</p>
                  <p>{job.location} | {job.salary}</p>
                  <p style={{ color: '#666', fontSize: '0.9rem' }}>{job.description}</p>
                  {user?.role === 'jobseeker' && (
                    <button
                      onClick={() => navigate(`/apply/${job._id}`)}
                      style={{
                        padding: '8px 16px',
                        backgroundColor: '#667eea',
                        color: 'white',
                        border: 'none',
                        borderRadius: 6,
                        cursor: 'pointer',
                        marginTop: 10
                      }}
                    >
                      應徵
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        );
      case 'notifications':
        navigate('/notifications');
        return null;
      case 'resume':
        navigate('/resume');
        return null;
      case 'forum':
        navigate('/forum');
        return null;
      case 'settings':
        navigate('/settings');
        return null;
      default:
        return null;
    }
  };

  if (!user) return null;

  return (
    <div style={{ display: 'flex', minHeight: '100vh', backgroundColor: '#f5f5f5' }}>
      {/* 側邊欄 */}
      <div style={{
        width: 250,
        backgroundColor: 'white',
        boxShadow: '2px 0 5px rgba(0,0,0,0.1)',
        display: 'flex',
        flexDirection: 'column'
      }}>
        {/* Logo */}
        <div style={{
          padding: 24,
          borderBottom: '1px solid #eee',
          textAlign: 'center'
        }}>
          <h1 style={{
            fontSize: '1.5rem',
            fontWeight: 'bold',
            color: '#667eea',
            margin: 0
          }}>
            Find Job
          </h1>
        </div>

        {/* 用戶資訊 */}
        <div style={{
          padding: 20,
          borderBottom: '1px solid #eee',
          backgroundColor: '#f9f9f9'
        }}>
          <p style={{ fontWeight: 'bold', marginBottom: 4 }}>{user.name}</p>
          <p style={{ fontSize: '0.85rem', color: '#666' }}>
            {user.role === 'employer' ? '雇主' : '求職者'}
          </p>
        </div>

        {/* 導航 */}
        <nav style={{ flex: 1, padding: 16 }}>
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              style={{
                width: '100%',
                padding: '12px 16px',
                marginBottom: 8,
                textAlign: 'left',
                backgroundColor: activeTab === item.id ? '#667eea' : 'transparent',
                color: activeTab === item.id ? 'white' : '#333',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer',
                fontSize: '1rem',
                display: 'flex',
                alignItems: 'center',
                gap: 12,
                transition: 'background-color 0.2s'
              }}
              onMouseOver={(e) => {
                if (activeTab !== item.id) {
                  e.target.style.backgroundColor = '#f0f0f0';
                }
              }}
              onMouseOut={(e) => {
                if (activeTab !== item.id) {
                  e.target.style.backgroundColor = 'transparent';
                }
              }}
            >
              <span>{item.icon}</span>
              {item.label}
            </button>
          ))}
        </nav>

        {/* 登出 */}
        <div style={{ padding: 16, borderTop: '1px solid #eee' }}>
          <button
            onClick={logout}
            style={{
              width: '100%',
              padding: '12px 16px',
              backgroundColor: '#dc3545',
              color: 'white',
              border: 'none',
              borderRadius: 8,
              cursor: 'pointer',
              fontSize: '1rem',
              fontWeight: 'bold'
            }}
          >
            登出
          </button>
        </div>
      </div>

      {/* 主內容區 */}
      <div style={{ flex: 1, padding: 32, overflowY: 'auto' }}>
        {renderContent()}
      </div>
    </div>
  );
}
