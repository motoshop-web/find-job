import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { forumAPI } from '../api';

export default function Forum() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [newPost, setNewPost] = useState({ title: '', content: '', tags: '' });
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedTag, setSelectedTag] = useState('all');

  useEffect(() => {
    // 未登入用戶也可以瀏覽論壇
    fetchPosts();
  }, []);

  const fetchPosts = async () => {
    try {
      const res = await forumAPI.getAll();
      setPosts(res.data);
    } catch (err) {
      console.error('Failed to fetch posts:', err);
    } finally {
      setLoading(false);
    }
  };

  const allTags = ['all', ...new Set(posts.flatMap(post => post.tags || []))];

  const filteredPosts = posts.filter(post => {
    const matchKeyword = post.title?.toLowerCase().includes(searchKeyword.toLowerCase()) ||
                         post.content?.toLowerCase().includes(searchKeyword.toLowerCase());
    const matchTag = selectedTag === 'all' || post.tags?.includes(selectedTag);
    return matchKeyword && matchTag;
  });

  const handleCreatePost = async () => {
    if (newPost.title && newPost.content) {
      try {
        const res = await forumAPI.create({
          title: newPost.title,
          content: newPost.content,
          tags: newPost.tags.split(',').map(t => t.trim()).filter(t => t)
        });
        setPosts([res.data, ...posts]);
        setNewPost({ title: '', content: '', tags: '' });
        setShowCreatePost(false);
      } catch (err) {
        console.error('Failed to create post:', err);
        alert('發布失敗，請稍後再試');
      }
    }
  };

  const handleLike = async (id) => {
    try {
      const res = await forumAPI.like(id);
      setPosts(posts.map(post =>
        post._id === id
          ? { ...post, likes: res.data.likes, liked: res.data.liked }
          : post
      ));
    } catch (err) {
      console.error('Failed to like post:', err);
    }
  };

  const formatDate = (date) => {
    if (!date) return '';
    const d = new Date(date);
    const now = new Date();
    const diff = now - d;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (hours < 1) return '剛剛';
    if (hours < 24) return `${hours} 小時前`;
    if (days < 7) return `${days} 天前`;
    return d.toLocaleDateString('zh-TW');
  };

  if (!user) return null;

  return (
    <div style={{ padding: 32, maxWidth: 1000, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', color: '#333' }}>論壇</h1>
        <button
          onClick={() => setShowCreatePost(true)}
          style={{
            padding: '10px 20px',
            backgroundColor: '#667eea',
            color: 'white',
            border: 'none',
            borderRadius: 6,
            cursor: 'pointer',
            fontSize: '1rem'
          }}
        >
          發布新帖
        </button>
      </div>

      {/* 搜尋和篩選 */}
      <div style={{ display: 'flex', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <input
          type="text"
          placeholder="搜尋帖子..."
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
          style={{
            flex: 1,
            minWidth: 200,
            padding: 12,
            border: '1px solid #ddd',
            borderRadius: 8
          }}
        />
        <select
          value={selectedTag}
          onChange={(e) => setSelectedTag(e.target.value)}
          style={{
            padding: 12,
            border: '1px solid #ddd',
            borderRadius: 8,
            minWidth: 150
          }}
        >
          {allTags.map(tag => (
            <option key={tag} value={tag}>
              {tag === 'all' ? '所有標籤' : tag}
            </option>
          ))}
        </select>
      </div>

      {/* 發布新帖表單 */}
      {showCreatePost && (
        <div style={{
          backgroundColor: 'white',
          padding: 24,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
          marginBottom: 24
        }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 16 }}>發布新帖</h2>
          <input
            type="text"
            placeholder="標題"
            value={newPost.title}
            onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
            style={{
              width: '100%',
              padding: 12,
              border: '1px solid #ddd',
              borderRadius: 8,
              marginBottom: 12,
              fontSize: '1rem'
            }}
          />
          <textarea
            placeholder="分享您的想法..."
            value={newPost.content}
            onChange={(e) => setNewPost({ ...newPost, content: e.target.value })}
            rows={5}
            style={{
              width: '100%',
              padding: 12,
              border: '1px solid #ddd',
              borderRadius: 8,
              marginBottom: 12,
              resize: 'vertical',
              fontSize: '1rem'
            }}
          />
          <input
            type="text"
            placeholder="標籤（用逗號分隔，例如：求職,面試,職涯）"
            value={newPost.tags}
            onChange={(e) => setNewPost({ ...newPost, tags: e.target.value })}
            style={{
              width: '100%',
              padding: 12,
              border: '1px solid #ddd',
              borderRadius: 8,
              marginBottom: 16,
              fontSize: '1rem'
            }}
          />
          <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
            <button
              onClick={() => setShowCreatePost(false)}
              style={{
                padding: '10px 20px',
                backgroundColor: '#e0e0e0',
                color: '#333',
                border: 'none',
                borderRadius: 6,
                cursor: 'pointer'
              }}
            >
              取消
            </button>
            <button
              onClick={handleCreatePost}
              style={{
                padding: '10px 20px',
                backgroundColor: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: 6,
                cursor: 'pointer'
              }}
            >
              發布
            </button>
          </div>
        </div>
      )}

      {/* 帖子列表 */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#666' }}>載入中...</div>
        ) : filteredPosts.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: 60,
            backgroundColor: 'white',
            borderRadius: 12,
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <span style={{ fontSize: '3rem' }}>💬</span>
            <p style={{ color: '#666', marginTop: 16 }}>沒有找到相關帖子</p>
          </div>
        ) : (
          filteredPosts.map(post => (
            <div
              key={post._id}
              style={{
                backgroundColor: 'white',
                padding: 24,
                borderRadius: 12,
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                cursor: 'pointer',
                transition: 'transform 0.2s, box-shadow 0.2s'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#333', margin: '0 0 8px 0' }}>
                    {post.title}
                  </h3>
                  <p style={{ color: '#666', margin: '0 0 12px 0', lineHeight: 1.6 }}>
                    {post.content?.length > 150 ? post.content.substring(0, 150) + '...' : post.content}
                  </p>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: 12 }}>
                    {post.tags?.map((tag, index) => (
                      <span key={index} style={{
                        backgroundColor: '#e9ecef',
                        color: '#495057',
                        padding: '4px 10px',
                        borderRadius: 12,
                        fontSize: '0.85rem'
                      }}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontSize: '0.9rem', color: '#666' }}>
                    <span>👤 {post.author?.name || '匿名'}</span>
                    <span>• {post.author?.role === 'employer' ? '雇主' : '求職者'}</span>
                    <span>• {formatDate(post.createdAt)}</span>
                  </div>
                </div>
              </div>

              {/* 互動區域 */}
              <div style={{
                display: 'flex',
                gap: 24,
                marginTop: 16,
                paddingTop: 16,
                borderTop: '1px solid #eee'
              }}>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    handleLike(post._id);
                  }}
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    color: post.liked ? '#667eea' : '#666',
                    fontSize: '0.95rem'
                  }}
                >
                  <span>👍</span>
                  <span>{post.likes?.length || 0}</span>
                </button>
                <button
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    backgroundColor: 'transparent',
                    border: 'none',
                    cursor: 'pointer',
                    color: '#666',
                    fontSize: '0.95rem'
                  }}
                >
                  <span>💬</span>
                  <span>{post.comments?.length || 0} 留言</span>
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
