import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { notificationsAPI } from '../api';

export default function Notifications() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    fetchNotifications();
  }, [user, navigate]);

  const fetchNotifications = async () => {
    try {
      const res = await notificationsAPI.getAll();
      setNotifications(res.data);
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredNotifications = filter === 'unread'
    ? notifications.filter(n => !n.read)
    : notifications;

  const markAsRead = async (id) => {
    try {
      await notificationsAPI.markAsRead(id);
      setNotifications(notifications.map(n =>
        n._id === id ? { ...n, read: true } : n
      ));
    } catch (err) {
      console.error('Failed to mark as read:', err);
    }
  };

  const markAllAsRead = async () => {
    try {
      await notificationsAPI.markAllAsRead();
      setNotifications(notifications.map(n => ({ ...n, read: true })));
    } catch (err) {
      console.error('Failed to mark all as read:', err);
    }
  };

  const deleteNotification = async (id) => {
    try {
      await notificationsAPI.delete(id);
      setNotifications(notifications.filter(n => n._id !== id));
    } catch (err) {
      console.error('Failed to delete notification:', err);
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'application': return '📨';
      case 'recommendation': return '💡';
      case 'reminder': return '⏰';
      case 'system': return '⚙️';
      default: return '🔔';
    }
  };

  const formatDate = (date) => {
    const d = new Date(date);
    const now = new Date();
    const diff = now - d;
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (hours < 1) return '剛剛';
    if (hours < 24) return `${hours} 小時前`;
    if (days < 7) return `${days} 天前`;
    return d.toLocaleDateString('zh-TW');
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  if (!user) return null;

  return (
    <div style={{ padding: 32 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', color: '#333' }}>
          通知中心
          {unreadCount > 0 && (
            <span style={{
              backgroundColor: '#dc3545',
              color: 'white',
              padding: '2px 8px',
              borderRadius: 12,
              fontSize: '0.875rem',
              marginLeft: 8
            }}>
              {unreadCount} 未讀
            </span>
          )}
        </h1>
        {unreadCount > 0 && (
          <button
            onClick={markAllAsRead}
            style={{
              padding: '8px 16px',
              backgroundColor: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 6,
              cursor: 'pointer'
            }}
          >
            全部標記為已讀
          </button>
        )}
      </div>

      {/* 篩選器 */}
      <div style={{ marginBottom: 20 }}>
        <button
          onClick={() => setFilter('all')}
          style={{
            padding: '8px 16px',
            marginRight: 8,
            backgroundColor: filter === 'all' ? '#667eea' : '#e0e0e0',
            color: filter === 'all' ? 'white' : '#333',
            border: 'none',
            borderRadius: 20,
            cursor: 'pointer'
          }}
        >
          全部
        </button>
        <button
          onClick={() => setFilter('unread')}
          style={{
            padding: '8px 16px',
            backgroundColor: filter === 'unread' ? '#667eea' : '#e0e0e0',
            color: filter === 'unread' ? 'white' : '#333',
            border: 'none',
            borderRadius: 20,
            cursor: 'pointer'
          }}
        >
          未讀
        </button>
      </div>

      {/* 通知列表 */}
      <div>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 40, color: '#666' }}>
            載入中...
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: 60,
            backgroundColor: 'white',
            borderRadius: 12,
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <span style={{ fontSize: '3rem' }}>🔔</span>
            <p style={{ color: '#666', marginTop: 16 }}>
              {filter === 'unread' ? '沒有未讀通知' : '目前沒有通知'}
            </p>
          </div>
        ) : (
          filteredNotifications.map(notification => (
            <div
              key={notification._id}
              style={{
                backgroundColor: 'white',
                padding: 20,
                marginBottom: 12,
                borderRadius: 12,
                boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                borderLeft: notification.read ? '4px solid #e0e0e0' : '4px solid #667eea',
                display: 'flex',
                alignItems: 'flex-start',
                gap: 16
              }}
            >
              <span style={{ fontSize: '1.5rem' }}>{getTypeIcon(notification.type)}</span>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                  <h3 style={{
                    fontWeight: notification.read ? 'normal' : 'bold',
                    color: '#333',
                    margin: 0
                  }}>
                    {notification.title}
                  </h3>
                  <span style={{ fontSize: '0.8rem', color: '#999' }}>{formatDate(notification.createdAt)}</span>
                </div>
                <p style={{ color: '#666', margin: '8px 0 0 0' }}>{notification.message}</p>
                <div style={{ marginTop: 12 }}>
                  {!notification.read && (
                    <button
                      onClick={() => markAsRead(notification._id)}
                      style={{
                        padding: '6px 12px',
                        backgroundColor: '#e0e0e0',
                        color: '#333',
                        border: 'none',
                        borderRadius: 4,
                        cursor: 'pointer',
                        fontSize: '0.85rem'
                      }}
                    >
                      標記為已讀
                    </button>
                  )}
                  <button
                    onClick={() => deleteNotification(notification._id)}
                    style={{
                      padding: '6px 12px',
                      marginLeft: 8,
                      backgroundColor: '#dc3545',
                      color: 'white',
                      border: 'none',
                      borderRadius: 4,
                      cursor: 'pointer',
                      fontSize: '0.85rem'
                    }}
                  >
                    刪除
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
