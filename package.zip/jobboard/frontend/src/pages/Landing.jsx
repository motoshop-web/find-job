import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Landing() {
  const navigate = useNavigate();
  const { user } = useAuth();

  // 如果已登入，直接跳轉到儀表板
  if (user) {
    navigate('/dashboard');
    return null;
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      color: 'white',
      textAlign: 'center',
      padding: '20px'
    }}>
      {/* Logo 和標題 */}
      <div style={{ marginBottom: 60 }}>
        <h1 style={{
          fontSize: '4rem',
          fontWeight: 'bold',
          marginBottom: 16,
          letterSpacing: '-2px',
          textShadow: '2px 2px 4px rgba(0,0,0,0.2)'
        }}>
          Find Job
        </h1>
        <p style={{
          fontSize: '1.25rem',
          opacity: 0.9,
          maxWidth: 400
        }}>
          找到理想工作，開啟職涯新篇章
        </p>
      </div>

      {/* 主要功能按鈕 - 未登入用戶可見 */}
      <div style={{
        display: 'flex',
        gap: 16,
        flexWrap: 'wrap',
        justifyContent: 'center',
        marginBottom: 40
      }}>
        <button
          onClick={() => navigate('/jobs')}
          style={{
            padding: '14px 32px',
            fontSize: '1rem',
            fontWeight: 'bold',
            backgroundColor: 'white',
            color: '#667eea',
            border: 'none',
            borderRadius: 50,
            cursor: 'pointer',
            transition: 'transform 0.2s, box-shadow 0.2s',
            boxShadow: '0 4px 15px rgba(0,0,0,0.2)'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'scale(1.05)';
            e.target.style.boxShadow = '0 6px 20px rgba(0,0,0,0.3)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'scale(1)';
            e.target.style.boxShadow = '0 4px 15px rgba(0,0,0,0.2)';
          }}
        >
          找工作
        </button>
        <button
          onClick={() => navigate('/forum')}
          style={{
            padding: '14px 32px',
            fontSize: '1rem',
            fontWeight: 'bold',
            backgroundColor: 'rgba(255,255,255,0.2)',
            color: 'white',
            border: '2px solid white',
            borderRadius: 50,
            cursor: 'pointer',
            transition: 'transform 0.2s, background-color 0.2s',
            boxShadow: '0 4px 15px rgba(0,0,0,0.2)'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'scale(1.05)';
            e.target.style.backgroundColor = 'rgba(255,255,255,0.3)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'scale(1)';
            e.target.style.backgroundColor = 'rgba(255,255,255,0.2)';
          }}
        >
          論壇
        </button>
      </div>

      {/* 登入/註冊按鈕 */}
      <div style={{
        display: 'flex',
        gap: 16,
        flexWrap: 'wrap',
        justifyContent: 'center'
      }}>
        <button
          onClick={() => navigate('/login')}
          style={{
            padding: '12px 32px',
            fontSize: '1rem',
            fontWeight: 'bold',
            backgroundColor: 'transparent',
            color: 'white',
            border: '2px solid rgba(255,255,255,0.6)',
            borderRadius: 50,
            cursor: 'pointer',
            transition: 'transform 0.2s, background-color 0.2s'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'scale(1.05)';
            e.target.style.backgroundColor = 'rgba(255,255,255,0.1)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'scale(1)';
            e.target.style.backgroundColor = 'transparent';
          }}
        >
          登入
        </button>
        <button
          onClick={() => navigate('/register')}
          style={{
            padding: '12px 32px',
            fontSize: '1rem',
            fontWeight: 'bold',
            backgroundColor: 'rgba(255,255,255,0.15)',
            color: 'white',
            border: '2px solid white',
            borderRadius: 50,
            cursor: 'pointer',
            transition: 'transform 0.2s, background-color 0.2s'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'scale(1.05)';
            e.target.style.backgroundColor = 'rgba(255,255,255,0.25)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'scale(1)';
            e.target.style.backgroundColor = 'rgba(255,255,255,0.15)';
          }}
        >
          註冊
        </button>
      </div>

      {/* 底部版權 */}
      <div style={{
        position: 'absolute',
        bottom: 20,
        fontSize: '0.875rem',
        opacity: 0.7
      }}>
        © 2024 Find Job. All rights reserved.
      </div>
    </div>
  );
}
