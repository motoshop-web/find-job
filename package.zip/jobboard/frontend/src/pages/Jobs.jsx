import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { jobsAPI } from '../api';

export default function Jobs() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedLocation, setSelectedLocation] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  useEffect(() => {
    fetchJobs();
  }, []);

  const fetchJobs = async () => {
    try {
      const res = await jobsAPI.getAll();
      setJobs(res.data);
    } catch (err) {
      console.error('Failed to fetch jobs:', err);
    } finally {
      setLoading(false);
    }
  };

  const locations = ['all', ...new Set(jobs.map(job => job.location).filter(Boolean))];
  const jobTypes = ['all', ...new Set(jobs.map(job => job.type).filter(Boolean))];

  const filteredJobs = jobs.filter(job => {
    const matchKeyword = job.title?.toLowerCase().includes(searchKeyword.toLowerCase()) ||
                         job.description?.toLowerCase().includes(searchKeyword.toLowerCase()) ||
                         job.companyName?.toLowerCase().includes(searchKeyword.toLowerCase());
    const matchLocation = selectedLocation === 'all' || job.location === selectedLocation;
    const matchType = selectedType === 'all' || job.type === selectedType;
    return matchKeyword && matchLocation && matchType;
  });

  const handleApply = (jobId) => {
    if (!user) {
      navigate('/login');
      return;
    }
    navigate(`/apply/${jobId}`);
  };

  const formatDate = (date) => {
    const d = new Date(date);
    return d.toLocaleDateString('zh-TW');
  };

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f5f5f5',
      padding: '40px 20px'
    }}>
      {/* Header */}
      <div style={{
        maxWidth: 1200,
        margin: '0 auto',
        marginBottom: 32
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
          <h1 style={{ fontSize: '2rem', fontWeight: 'bold', color: '#333', margin: 0 }}>
            找工作
          </h1>
          {user ? (
            <button
              onClick={() => navigate('/dashboard')}
              style={{
                padding: '10px 20px',
                backgroundColor: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer',
                fontWeight: 'bold'
              }}
            >
              返回儀表板
            </button>
          ) : (
            <div style={{ display: 'flex', gap: 12 }}>
              <button
                onClick={() => navigate('/login')}
                style={{
                  padding: '10px 20px',
                  backgroundColor: 'white',
                  color: '#667eea',
                  border: '2px solid #667eea',
                  borderRadius: 8,
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                登入
              </button>
              <button
                onClick={() => navigate('/register')}
                style={{
                  padding: '10px 20px',
                  backgroundColor: '#667eea',
                  color: 'white',
                  border: 'none',
                  borderRadius: 8,
                  cursor: 'pointer',
                  fontWeight: 'bold'
                }}
              >
                註冊
              </button>
            </div>
          )}
        </div>

        {/* 搜尋和篩選 */}
        <div style={{
          backgroundColor: 'white',
          padding: 24,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
            <input
              type="text"
              placeholder="搜尋職缺、公司..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              style={{
                flex: 1,
                minWidth: 250,
                padding: '12px 16px',
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
            <select
              value={selectedLocation}
              onChange={(e) => setSelectedLocation(e.target.value)}
              style={{
                padding: '12px 16px',
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem',
                minWidth: 150
              }}
            >
              {locations.map(loc => (
                <option key={loc} value={loc}>
                  {loc === 'all' ? '所有地區' : loc}
                </option>
              ))}
            </select>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              style={{
                padding: '12px 16px',
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem',
                minWidth: 150
              }}
            >
              {jobTypes.map(type => (
                <option key={type} value={type}>
                  {type === 'all' ? '所有類型' : type}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* 職缺列表 */}
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        {loading ? (
          <div style={{ textAlign: 'center', padding: 60, color: '#666' }}>
            載入中...
          </div>
        ) : filteredJobs.length === 0 ? (
          <div style={{
            textAlign: 'center',
            padding: 60,
            backgroundColor: 'white',
            borderRadius: 12,
            boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
          }}>
            <span style={{ fontSize: '3rem' }}>💼</span>
            <p style={{ color: '#666', marginTop: 16 }}>
              {searchKeyword || selectedLocation !== 'all' || selectedType !== 'all'
                ? '找不到符合條件的職缺'
                : '目前沒有職缺'}
            </p>
          </div>
        ) : (
          <div style={{ display: 'grid', gap: 16 }}>
            {filteredJobs.map(job => (
              <div
                key={job._id}
                style={{
                  backgroundColor: 'white',
                  padding: 24,
                  borderRadius: 12,
                  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                  transition: 'transform 0.2s, box-shadow 0.2s'
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 4px 16px rgba(0,0,0,0.15)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 2px 8px rgba(0,0,0,0.1)';
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <div style={{ flex: 1 }}>
                    <h3 style={{
                      fontSize: '1.25rem',
                      fontWeight: 'bold',
                      color: '#333',
                      margin: '0 0 8px 0'
                    }}>
                      {job.title}
                    </h3>
                    <p style={{
                      color: '#667eea',
                      fontWeight: 'bold',
                      margin: '0 0 12px 0'
                    }}>
                      {job.companyName}
                    </p>
                    <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', marginBottom: 12 }}>
                      {job.location && (
                        <span style={{ color: '#666', fontSize: '0.9rem' }}>
                          📍 {job.location}
                        </span>
                      )}
                      {job.type && (
                        <span style={{ color: '#666', fontSize: '0.9rem' }}>
                          💼 {job.type}
                        </span>
                      )}
                      {job.salary && (
                        <span style={{ color: '#27ae60', fontWeight: 'bold', fontSize: '0.9rem' }}>
                          💰 {job.salary}
                        </span>
                      )}
                    </div>
                    <p style={{
                      color: '#666',
                      fontSize: '0.9rem',
                      lineHeight: 1.6,
                      margin: 0,
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      display: '-webkit-box',
                      WebkitLineClamp: 2,
                      WebkitBoxOrient: 'vertical'
                    }}>
                      {job.description}
                    </p>
                  </div>
                  <div style={{ marginLeft: 24 }}>
                    <button
                      onClick={() => handleApply(job._id)}
                      style={{
                        padding: '12px 24px',
                        backgroundColor: '#667eea',
                        color: 'white',
                        border: 'none',
                        borderRadius: 8,
                        cursor: 'pointer',
                        fontWeight: 'bold',
                        whiteSpace: 'nowrap'
                      }}
                    >
                      立即應徵
                    </button>
                    <p style={{
                      fontSize: '0.8rem',
                      color: '#999',
                      marginTop: 8,
                      textAlign: 'center'
                    }}>
                      {formatDate(job.createdAt)}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 底部 */}
      <div style={{
        maxWidth: 1200,
        margin: '40px auto 0',
        textAlign: 'center',
        color: '#999',
        fontSize: '0.9rem'
      }}>
        <p>總共 {filteredJobs.length} 個職缺</p>
      </div>
    </div>
  );
}
