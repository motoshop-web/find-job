import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Settings() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    applicationUpdates: true,
    jobRecommendations: false,
    forumReplies: true
  });

  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  const handleSave = () => {
    // 模擬保存
    localStorage.setItem('user', JSON.stringify({ ...user, name: formData.name, email: formData.email }));
    localStorage.setItem('notificationPrefs', JSON.stringify(notifications));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleChangePassword = () => {
    if (formData.newPassword !== formData.confirmPassword) {
      alert('新密碼與確認密碼不符');
      return;
    }
    if (formData.newPassword.length < 6) {
      alert('密碼長度至少需要 6 個字元');
      return;
    }
    alert('密碼修改成功！');
    setFormData({ ...formData, currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  if (!user) return null;

  return (
    <div style={{ padding: 32, maxWidth: 800, margin: '0 auto' }}>
      <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', color: '#333', marginBottom: 24 }}>個人設定</h1>

      {/* 標籤導航 */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 24, borderBottom: '1px solid #eee' }}>
        <button
          onClick={() => setActiveTab('profile')}
          style={{
            padding: '12px 24px',
            backgroundColor: 'transparent',
            border: 'none',
            borderBottom: activeTab === 'profile' ? '2px solid #667eea' : '2px solid transparent',
            color: activeTab === 'profile' ? '#667eea' : '#666',
            cursor: 'pointer',
            fontSize: '1rem',
            fontWeight: activeTab === 'profile' ? 'bold' : 'normal'
          }}
        >
          個人資料
        </button>
        <button
          onClick={() => setActiveTab('password')}
          style={{
            padding: '12px 24px',
            backgroundColor: 'transparent',
            border: 'none',
            borderBottom: activeTab === 'password' ? '2px solid #667eea' : '2px solid transparent',
            color: activeTab === 'password' ? '#667eea' : '#666',
            cursor: 'pointer',
            fontSize: '1rem',
            fontWeight: activeTab === 'password' ? 'bold' : 'normal'
          }}
        >
          修改密碼
        </button>
        <button
          onClick={() => setActiveTab('notifications')}
          style={{
            padding: '12px 24px',
            backgroundColor: 'transparent',
            border: 'none',
            borderBottom: activeTab === 'notifications' ? '2px solid #667eea' : '2px solid transparent',
            color: activeTab === 'notifications' ? '#667eea' : '#666',
            cursor: 'pointer',
            fontSize: '1rem',
            fontWeight: activeTab === 'notifications' ? 'bold' : 'normal'
          }}
        >
          通知設定
        </button>
      </div>

      {/* 個人資料 */}
      {activeTab === 'profile' && (
        <div style={{
          backgroundColor: 'white',
          padding: 32,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          {/* 頭像區域 */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 32 }}>
            <div style={{
              width: 100,
              height: 100,
              borderRadius: '50%',
              backgroundColor: '#667eea',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '2.5rem',
              fontWeight: 'bold'
            }}>
              {formData.name ? formData.name.charAt(0).toUpperCase() : '?'}
            </div>
            <div>
              <button style={{
                padding: '10px 20px',
                backgroundColor: '#e9ecef',
                color: '#333',
                border: 'none',
                borderRadius: 6,
                cursor: 'pointer',
                marginRight: 12
              }}>
                上傳頭像
              </button>
              <span style={{ color: '#666', fontSize: '0.9rem' }}>支援 JPG, PNG 格式，最大 2MB</span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 20 }}>
            <div>
              <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>姓名</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              />
            </div>
            <div>
              <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              />
            </div>
            <div>
              <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>電話</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              />
            </div>
            <div>
              <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>帳號類型</label>
              <input
                type="text"
                value={user?.role === 'employer' ? '雇主' : '求職者'}
                disabled
                style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8, backgroundColor: '#f8f9fa' }}
              />
            </div>
          </div>

          <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end', gap: 12 }}>
            <button
              onClick={() => navigate('/dashboard')}
              style={{
                padding: '12px 24px',
                backgroundColor: '#e0e0e0',
                color: '#333',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer'
              }}
            >
              取消
            </button>
            <button
              onClick={handleSave}
              style={{
                padding: '12px 24px',
                backgroundColor: saved ? '#28a745' : '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer'
              }}
            >
              {saved ? '已保存 ✓' : '保存更改'}
            </button>
          </div>
        </div>
      )}

      {/* 修改密碼 */}
      {activeTab === 'password' && (
        <div style={{
          backgroundColor: 'white',
          padding: 32,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 24 }}>修改密碼</h2>

          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>目前密碼</label>
            <input
              type="password"
              value={formData.currentPassword}
              onChange={(e) => setFormData({ ...formData, currentPassword: e.target.value })}
              style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              placeholder="請輸入目前密碼"
            />
          </div>

          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>新密碼</label>
            <input
              type="password"
              value={formData.newPassword}
              onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
              style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              placeholder="請輸入新密碼（至少 6 個字元）"
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: '500' }}>確認新密碼</label>
            <input
              type="password"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              style={{ width: '100%', padding: 12, border: '1px solid #ddd', borderRadius: 8 }}
              placeholder="請再次輸入新密碼"
            />
          </div>

          <button
            onClick={handleChangePassword}
            style={{
              padding: '12px 24px',
              backgroundColor: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 8,
              cursor: 'pointer',
              fontSize: '1rem'
            }}
          >
            確認修改
          </button>
        </div>
      )}

      {/* 通知設定 */}
      {activeTab === 'notifications' && (
        <div style={{
          backgroundColor: 'white',
          padding: 32,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 24 }}>通知設定</h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={notifications.emailNotifications}
                onChange={(e) => setNotifications({ ...notifications, emailNotifications: e.target.checked })}
                style={{ width: 20, height: 20, cursor: 'pointer' }}
              />
              <div>
                <p style={{ fontWeight: '500', margin: 0 }}>Email 通知</p>
                <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>接收網站相關的 Email 通知</p>
              </div>
            </label>

            <label style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={notifications.applicationUpdates}
                onChange={(e) => setNotifications({ ...notifications, applicationUpdates: e.target.checked })}
                style={{ width: 20, height: 20, cursor: 'pointer' }}
              />
              <div>
                <p style={{ fontWeight: '500', margin: 0 }}>應徵進度更新</p>
                <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>當您的應徵狀態有變化時通知您</p>
              </div>
            </label>

            <label style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={notifications.jobRecommendations}
                onChange={(e) => setNotifications({ ...notifications, jobRecommendations: e.target.checked })}
                style={{ width: 20, height: 20, cursor: 'pointer' }}
              />
              <div>
                <p style={{ fontWeight: '500', margin: 0 }}>職缺推薦</p>
                <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>根據您的條件推薦相關職缺</p>
              </div>
            </label>

            <label style={{ display: 'flex', alignItems: 'center', gap: 12, cursor: 'pointer' }}>
              <input
                type="checkbox"
                checked={notifications.forumReplies}
                onChange={(e) => setNotifications({ ...notifications, forumReplies: e.target.checked })}
                style={{ width: 20, height: 20, cursor: 'pointer' }}
              />
              <div>
                <p style={{ fontWeight: '500', margin: 0 }}>論壇回覆通知</p>
                <p style={{ color: '#666', fontSize: '0.9rem', margin: 0 }}>當您的帖子有新回覆時通知您</p>
              </div>
            </label>
          </div>

          <div style={{ marginTop: 24, display: 'flex', justifyContent: 'flex-end' }}>
            <button
              onClick={handleSave}
              style={{
                padding: '12px 24px',
                backgroundColor: saved ? '#28a745' : '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: 8,
                cursor: 'pointer'
              }}
            >
              {saved ? '已保存 ✓' : '保存設置'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
