import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authAPI } from '../api';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await authAPI.login(form);
      login(res.data.user, res.data.token);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || '登入失敗，請檢查您的帳號密碼');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: 20
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: 40,
        borderRadius: 16,
        boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
        width: '100%',
        maxWidth: 400
      }}>
        <h2 style={{
          textAlign: 'center',
          color: '#333',
          marginBottom: 8,
          fontSize: '1.75rem'
        }}>
          歡迎回來
        </h2>
        <p style={{
          textAlign: 'center',
          color: '#666',
          marginBottom: 32
        }}>
          登入您的 Find Job 帳號
        </p>

        {error && (
          <div style={{
            backgroundColor: '#fee2e2',
            color: '#dc2626',
            padding: 12,
            borderRadius: 8,
            marginBottom: 16,
            textAlign: 'center',
            fontSize: '0.9rem'
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 20 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              Email
            </label>
            <input
              type="email"
              placeholder="請輸入 Email"
              value={form.email}
              onChange={e => setForm({...form, email: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: 24 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              密碼
            </label>
            <input
              type="password"
              placeholder="請輸入密碼"
              value={form.password}
              onChange={e => setForm({...form, password: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: 14,
              backgroundColor: loading ? '#9ca3af' : '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 8,
              fontSize: '1rem',
              fontWeight: 'bold',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'background-color 0.2s'
            }}
          >
            {loading ? '登入中...' : '登入'}
          </button>
        </form>

        <p style={{
          textAlign: 'center',
          marginTop: 24,
          color: '#666'
        }}>
          還沒有帳號？{' '}
          <Link to="/register" style={{ color: '#667eea', fontWeight: 'bold' }}>
            立即註冊
          </Link>
        </p>

        <div style={{ textAlign: 'center', marginTop: 16 }}>
          <Link to="/" style={{ color: '#666', fontSize: '0.9rem' }}>
            ← 返回首頁
          </Link>
        </div>
      </div>
    </div>
  );
}
