import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { resumesAPI } from '../api';

export default function Resume() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [resume, setResume] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: '',
    location: '',
    summary: '',
    experience: [],
    education: [],
    skills: []
  });

  const [newSkill, setNewSkill] = useState('');
  const [newExperience, setNewExperience] = useState({ company: '', position: '', period: '', description: '' });
  const [newEducation, setNewEducation] = useState({ school: '', degree: '', year: '' });
  const [isPreview, setIsPreview] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }
    fetchResume();
  }, [user, navigate]);

  const fetchResume = async () => {
    try {
      const res = await resumesAPI.get();
      if (res.data && Object.keys(res.data).length > 0) {
        setResume(res.data);
      }
    } catch (err) {
      console.error('Failed to fetch resume:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await resumesAPI.update(resume);
      setTimeout(() => setSaving(false), 1000);
    } catch (err) {
      console.error('Failed to save resume:', err);
      setSaving(false);
    }
  };

  const addSkill = () => {
    if (newSkill.trim() && !resume.skills.includes(newSkill.trim())) {
      setResume({ ...resume, skills: [...resume.skills, newSkill.trim()] });
      setNewSkill('');
    }
  };

  const removeSkill = (skill) => {
    setResume({ ...resume, skills: resume.skills.filter(s => s !== skill) });
  };

  const addExperience = () => {
    if (newExperience.company && newExperience.position) {
      setResume({
        ...resume,
        experience: [...resume.experience, { ...newExperience }]
      });
      setNewExperience({ company: '', position: '', period: '', description: '' });
    }
  };

  const removeExperience = (index) => {
    setResume({
      ...resume,
      experience: resume.experience.filter((_, i) => i !== index)
    });
  };

  const addEducation = () => {
    if (newEducation.school && newEducation.degree) {
      setResume({
        ...resume,
        education: [...resume.education, { ...newEducation }]
      });
      setNewEducation({ school: '', degree: '', year: '' });
    }
  };

  const removeEducation = (index) => {
    setResume({
      ...resume,
      education: resume.education.filter((_, i) => i !== index)
    });
  };

  if (!user) return null;

  return (
    <div style={{ padding: 32, maxWidth: 900, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <h1 style={{ fontSize: '1.75rem', fontWeight: 'bold', color: '#333' }}>履歷表管理</h1>
        <div style={{ display: 'flex', gap: 12 }}>
          <button
            onClick={() => setIsPreview(!isPreview)}
            style={{
              padding: '10px 20px',
              backgroundColor: '#6c757d',
              color: 'white',
              border: 'none',
              borderRadius: 6,
              cursor: 'pointer'
            }}
          >
            {isPreview ? '編輯' : '預覽'}
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            style={{
              padding: '10px 20px',
              backgroundColor: saving ? '#28a745' : '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 6,
              cursor: saving ? 'default' : 'pointer',
              transition: 'background-color 0.2s'
            }}
          >
            {saving ? '已保存 ✓' : '保存'}
          </button>
        </div>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: 40 }}>載入中...</div>
      ) : isPreview ? (
        // 預覽模式
        <div style={{
          backgroundColor: 'white',
          padding: 40,
          borderRadius: 12,
          boxShadow: '0 2px 8px rgba(0,0,0,0.1)'
        }}>
          <div style={{ borderBottom: '2px solid #667eea', paddingBottom: 20, marginBottom: 20 }}>
            <h2 style={{ fontSize: '1.5rem', color: '#333', margin: 0 }}>{resume.name || '您的姓名'}</h2>
            <p style={{ color: '#666', marginTop: 8 }}>
              {resume.email} | {resume.phone} | {resume.location}
            </p>
          </div>

          {resume.summary && (
            <div style={{ marginBottom: 24 }}>
              <h3 style={{ color: '#667eea', marginBottom: 8 }}>個人摘要</h3>
              <p style={{ color: '#666', lineHeight: 1.6 }}>{resume.summary}</p>
            </div>
          )}

          {resume.skills?.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <h3 style={{ color: '#667eea', marginBottom: 8 }}>技能</h3>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {resume.skills.map((skill, index) => (
                  <span key={index} style={{
                    backgroundColor: '#e9ecef',
                    padding: '4px 12px',
                    borderRadius: 16,
                    fontSize: '0.9rem'
                  }}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {resume.experience?.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <h3 style={{ color: '#667eea', marginBottom: 12 }}>工作經驗</h3>
              {resume.experience.map((exp, index) => (
                <div key={index} style={{ marginBottom: 16 }}>
                  <h4 style={{ fontWeight: 'bold', margin: 0 }}>{exp.position}</h4>
                  <p style={{ color: '#666', margin: '4px 0' }}>{exp.company} | {exp.period}</p>
                  <p style={{ color: '#666', fontSize: '0.9rem' }}>{exp.description}</p>
                </div>
              ))}
            </div>
          )}

          {resume.education?.length > 0 && (
            <div>
              <h3 style={{ color: '#667eea', marginBottom: 12 }}>教育背景</h3>
              {resume.education.map((edu, index) => (
                <div key={index}>
                  <h4 style={{ fontWeight: 'bold', margin: 0 }}>{edu.degree}</h4>
                  <p style={{ color: '#666', margin: '4px 0' }}>{edu.school} | {edu.year}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        // 編輯模式
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          {/* 基本資訊 */}
          <div style={{ backgroundColor: 'white', padding: 24, borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 16, color: '#333' }}>基本資訊</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 4, color: '#666' }}>姓名</label>
                <input
                  type="text"
                  value={resume.name}
                  onChange={(e) => setResume({ ...resume, name: e.target.value })}
                  style={{ width: '100%', padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 4, color: '#666' }}>Email</label>
                <input
                  type="email"
                  value={resume.email}
                  onChange={(e) => setResume({ ...resume, email: e.target.value })}
                  style={{ width: '100%', padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 4, color: '#666' }}>電話</label>
                <input
                  type="tel"
                  value={resume.phone}
                  onChange={(e) => setResume({ ...resume, phone: e.target.value })}
                  style={{ width: '100%', padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 4, color: '#666' }}>地址</label>
                <input
                  type="text"
                  value={resume.location}
                  onChange={(e) => setResume({ ...resume, location: e.target.value })}
                  style={{ width: '100%', padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
                />
              </div>
            </div>
            <div style={{ marginTop: 16 }}>
              <label style={{ display: 'block', marginBottom: 4, color: '#666' }}>個人摘要</label>
              <textarea
                value={resume.summary}
                onChange={(e) => setResume({ ...resume, summary: e.target.value })}
                rows={4}
                style={{ width: '100%', padding: 10, border: '1px solid #ddd', borderRadius: 6, resize: 'vertical' }}
                placeholder="簡單介紹您的背景和優勢..."
              />
            </div>
          </div>

          {/* 技能 */}
          <div style={{ backgroundColor: 'white', padding: 24, borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 16, color: '#333' }}>技能</h2>
            <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
              <input
                type="text"
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && addSkill()}
                placeholder="新增技能..."
                style={{ flex: 1, padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <button onClick={addSkill} style={{
                padding: '10px 20px',
                backgroundColor: '#667eea',
                color: 'white',
                border: 'none',
                borderRadius: 6,
                cursor: 'pointer'
              }}>
                新增
              </button>
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {resume.skills?.map((skill, index) => (
                <span key={index} style={{
                  backgroundColor: '#667eea',
                  color: 'white',
                  padding: '6px 12px',
                  borderRadius: 16,
                  fontSize: '0.9rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8
                }}>
                  {skill}
                  <button onClick={() => removeSkill(skill)} style={{
                    backgroundColor: 'rgba(255,255,255,0.3)',
                    border: 'none',
                    borderRadius: '50%',
                    width: 18,
                    height: 18,
                    cursor: 'pointer',
                    color: 'white',
                    fontSize: '0.7rem'
                  }}>×</button>
                </span>
              ))}
            </div>
          </div>

          {/* 工作經驗 */}
          <div style={{ backgroundColor: 'white', padding: 24, borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 16, color: '#333' }}>工作經驗</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
              <input
                type="text"
                value={newExperience.company}
                onChange={(e) => setNewExperience({ ...newExperience, company: e.target.value })}
                placeholder="公司名稱"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <input
                type="text"
                value={newExperience.position}
                onChange={(e) => setNewExperience({ ...newExperience, position: e.target.value })}
                placeholder="職位"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <input
                type="text"
                value={newExperience.period}
                onChange={(e) => setNewExperience({ ...newExperience, period: e.target.value })}
                placeholder="在職時間"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <input
                type="text"
                value={newExperience.description}
                onChange={(e) => setNewExperience({ ...newExperience, description: e.target.value })}
                placeholder="工作描述"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
            </div>
            <button onClick={addExperience} style={{
              marginTop: 12,
              padding: '10px 20px',
              backgroundColor: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 6,
              cursor: 'pointer'
            }}>
              新增工作經驗
            </button>

            {resume.experience?.map((exp, index) => (
              <div key={index} style={{
                marginTop: 16,
                padding: 16,
                backgroundColor: '#f8f9fa',
                borderRadius: 8,
                position: 'relative'
              }}>
                <button onClick={() => removeExperience(index)} style={{
                  position: 'absolute',
                  top: 8,
                  right: 8,
                  backgroundColor: '#dc3545',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  width: 24,
                  height: 24,
                  cursor: 'pointer'
                }}>×</button>
                <p style={{ fontWeight: 'bold', margin: 0 }}>{exp.position}</p>
                <p style={{ color: '#666', margin: '4px 0' }}>{exp.company} | {exp.period}</p>
                <p style={{ color: '#666', fontSize: '0.9rem' }}>{exp.description}</p>
              </div>
            ))}
          </div>

          {/* 教育背景 */}
          <div style={{ backgroundColor: 'white', padding: 24, borderRadius: 12, boxShadow: '0 2px 8px rgba(0,0,0,0.1)' }}>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 'bold', marginBottom: 16, color: '#333' }}>教育背景</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
              <input
                type="text"
                value={newEducation.school}
                onChange={(e) => setNewEducation({ ...newEducation, school: e.target.value })}
                placeholder="學校名稱"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <input
                type="text"
                value={newEducation.degree}
                onChange={(e) => setNewEducation({ ...newEducation, degree: e.target.value })}
                placeholder="學位/科系"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
              <input
                type="text"
                value={newEducation.year}
                onChange={(e) => setNewEducation({ ...newEducation, year: e.target.value })}
                placeholder="畢業年份"
                style={{ padding: 10, border: '1px solid #ddd', borderRadius: 6 }}
              />
            </div>
            <button onClick={addEducation} style={{
              marginTop: 12,
              padding: '10px 20px',
              backgroundColor: '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 6,
              cursor: 'pointer'
            }}>
              新增教育背景
            </button>

            {resume.education?.map((edu, index) => (
              <div key={index} style={{
                marginTop: 16,
                padding: 16,
                backgroundColor: '#f8f9fa',
                borderRadius: 8,
                position: 'relative'
              }}>
                <button onClick={() => removeEducation(index)} style={{
                  position: 'absolute',
                  top: 8,
                  right: 8,
                  backgroundColor: '#dc3545',
                  color: 'white',
                  border: 'none',
                  borderRadius: 4,
                  width: 24,
                  height: 24,
                  cursor: 'pointer'
                }}>×</button>
                <p style={{ fontWeight: 'bold', margin: 0 }}>{edu.degree}</p>
                <p style={{ color: '#666', margin: '4px 0' }}>{edu.school} | {edu.year}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
