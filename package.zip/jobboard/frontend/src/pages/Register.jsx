import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authAPI } from '../api';
import { useAuth } from '../context/AuthContext';

export default function Register() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: '',
    role: 'jobseeker',
    companyName: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (form.password !== form.confirmPassword) {
      setError('密碼與確認密碼不符');
      return;
    }

    if (form.password.length < 6) {
      setError('密碼長度至少需要 6 個字元');
      return;
    }

    setLoading(true);

    try {
      const { confirmPassword, ...registerData } = form;
      const res = await authAPI.register(registerData);
      login(res.data.user, res.data.token);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || '註冊失敗，請稍後再試');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      padding: 20
    }}>
      <div style={{
        backgroundColor: 'white',
        padding: 40,
        borderRadius: 16,
        boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
        width: '100%',
        maxWidth: 450
      }}>
        <h2 style={{
          textAlign: 'center',
          color: '#333',
          marginBottom: 8,
          fontSize: '1.75rem'
        }}>
          創建帳號
        </h2>
        <p style={{
          textAlign: 'center',
          color: '#666',
          marginBottom: 32
        }}>
          加入 Find Job 開始求職之旅
        </p>

        {error && (
          <div style={{
            backgroundColor: '#fee2e2',
            color: '#dc2626',
            padding: 12,
            borderRadius: 8,
            marginBottom: 16,
            textAlign: 'center',
            fontSize: '0.9rem'
          }}>
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              姓名
            </label>
            <input
              type="text"
              placeholder="請輸入姓名"
              value={form.name}
              onChange={e => setForm({...form, name: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              Email
            </label>
            <input
              type="email"
              placeholder="請輸入 Email"
              value={form.email}
              onChange={e => setForm({...form, email: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              密碼
            </label>
            <input
              type="password"
              placeholder="請輸入密碼（至少 6 個字元）"
              value={form.password}
              onChange={e => setForm({...form, password: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              確認密碼
            </label>
            <input
              type="password"
              placeholder="請再次輸入密碼"
              value={form.confirmPassword}
              onChange={e => setForm({...form, confirmPassword: e.target.value})}
              required
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem'
              }}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
              身份
            </label>
            <select
              value={form.role}
              onChange={e => setForm({...form, role: e.target.value})}
              style={{
                width: '100%',
                padding: 12,
                border: '1px solid #ddd',
                borderRadius: 8,
                fontSize: '1rem',
                backgroundColor: 'white'
              }}
            >
              <option value="jobseeker">求職者</option>
              <option value="employer">雇主</option>
            </select>
          </div>

          {form.role === 'employer' && (
            <div style={{ marginBottom: 24 }}>
              <label style={{ display: 'block', marginBottom: 8, color: '#333', fontWeight: 500 }}>
                公司名稱
              </label>
              <input
                type="text"
                placeholder="請輸入公司名稱"
                value={form.companyName}
                onChange={e => setForm({...form, companyName: e.target.value})}
                required
                style={{
                  width: '100%',
                  padding: 12,
                  border: '1px solid #ddd',
                  borderRadius: 8,
                  fontSize: '1rem'
                }}
              />
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              width: '100%',
              padding: 14,
              backgroundColor: loading ? '#9ca3af' : '#667eea',
              color: 'white',
              border: 'none',
              borderRadius: 8,
              fontSize: '1rem',
              fontWeight: 'bold',
              cursor: loading ? 'not-allowed' : 'pointer',
              transition: 'background-color 0.2s',
              marginTop: form.role === 'employer' ? 0 : 16
            }}
          >
            {loading ? '註冊中...' : '註冊'}
          </button>
        </form>

        <p style={{
          textAlign: 'center',
          marginTop: 24,
          color: '#666'
        }}>
          已有帳號？{' '}
          <Link to="/login" style={{ color: '#667eea', fontWeight: 'bold' }}>
            立即登入
          </Link>
        </p>

        <div style={{ textAlign: 'center', marginTop: 16 }}>
          <Link to="/" style={{ color: '#666', fontSize: '0.9rem' }}>
            ← 返回首頁
          </Link>
        </div>
      </div>
    </div>
  );
}
