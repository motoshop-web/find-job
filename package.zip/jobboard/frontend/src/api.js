import axios from 'axios';

// API 配置
const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000'
});

// 請求攔截器 - 添加 Token
API.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 回應攔截器 - 處理錯誤
API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token 過期，清除本地存儲
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/';
    }
    return Promise.reject(error);
  }
);

// API 方法封裝
export const authAPI = {
  login: (data) => API.post('/api/auth/login', data),
  register: (data) => API.post('/api/auth/register', data),
};

export const jobsAPI = {
  getAll: () => API.get('/api/jobs'),
  getOne: (id) => API.get(`/api/jobs/${id}`),
  create: (data) => API.post('/api/jobs', data),
  update: (id, data) => API.put(`/api/jobs/${id}`, data),
  delete: (id) => API.delete(`/api/jobs/${id}`),
};

export const applicationsAPI = {
  create: (data) => API.post('/api/applications', data),
  getByApplicant: (id) => API.get(`/api/applications/applicant/${id}`),
  getByJob: (id) => API.get(`/api/applications/job/${id}`),
  update: (id, data) => API.put(`/api/applications/${id}`, data),
};

export const notificationsAPI = {
  getAll: () => API.get('/api/notifications'),
  getUnreadCount: () => API.get('/api/notifications/unread-count'),
  markAsRead: (id) => API.put(`/api/notifications/${id}/read`),
  markAllAsRead: () => API.put('/api/notifications/read-all'),
  delete: (id) => API.delete(`/api/notifications/${id}`),
};

export const resumesAPI = {
  get: () => API.get('/api/resumes'),
  update: (data) => API.put('/api/resumes', data),
  addSkill: (skill) => API.post('/api/resumes/skills', { skill }),
  removeSkill: (skill) => API.delete(`/api/resumes/skills/${skill}`),
  addExperience: (data) => API.post('/api/resumes/experience', data),
  removeExperience: (index) => API.delete(`/api/resumes/experience/${index}`),
  addEducation: (data) => API.post('/api/resumes/education', data),
  removeEducation: (index) => API.delete(`/api/resumes/education/${index}`),
};

export const forumAPI = {
  getAll: (params) => API.get('/api/forum', { params }),
  getOne: (id) => API.get(`/api/forum/${id}`),
  create: (data) => API.post('/api/forum', data),
  update: (id, data) => API.put(`/api/forum/${id}`, data),
  delete: (id) => API.delete(`/api/forum/${id}`),
  like: (id) => API.post(`/api/forum/${id}/like`),
  addComment: (id, content) => API.post(`/api/forum/${id}/comments`, { content }),
  removeComment: (id, commentId) => API.delete(`/api/forum/${id}/comments/${commentId}`),
  getTags: () => API.get('/api/forum/meta/tags'),
};

export default API;
