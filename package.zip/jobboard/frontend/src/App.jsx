import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// 頁面組件
import Landing from './pages/Landing';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Jobs from './pages/Jobs';
import PostJob from './pages/PostJob';
import Apply from './pages/Apply';
import Applications from './pages/Applications';
import Notifications from './pages/Notifications';
import Resume from './pages/Resume';
import Forum from './pages/Forum';
import Settings from './pages/Settings';

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          {/* 未登入用戶可訪問 */}
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/forum" element={<Forum />} />

          {/* 登入後共用 */}
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/resume" element={<Resume />} />
          <Route path="/settings" element={<Settings />} />

          {/* 雇主專用 */}
          <Route path="/post-job" element={<PostJob />} />
          <Route path="/applications" element={<Applications />} />

          {/* 求職者專用 */}
          <Route path="/apply/:id" element={<Apply />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
