const express = require('express');
const jwt = require('jsonwebtoken');
const Notification = require('../models/Notification');

const router = express.Router();

// 認證中介軟體
const auth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: '未授權' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (error) {
    res.status(401).json({ message: '無效的認證' });
  }
};

// 獲取用戶所有通知
router.get('/', auth, async (req, res) => {
  try {
    const notifications = await Notification.find({ user: req.userId })
      .sort({ createdAt: -1 })
      .limit(50);
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 獲取未讀通知數量
router.get('/unread-count', auth, async (req, res) => {
  try {
    const count = await Notification.countDocuments({ user: req.userId, read: false });
    res.json({ count });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 標記單個通知為已讀
router.put('/:id/read', auth, async (req, res) => {
  try {
    const notification = await Notification.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      { read: true },
      { new: true }
    );
    if (!notification) return res.status(404).json({ message: '通知不存在' });
    res.json(notification);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 標記所有通知為已讀
router.put('/read-all', auth, async (req, res) => {
  try {
    await Notification.updateMany(
      { user: req.userId, read: false },
      { read: true }
    );
    res.json({ message: '所有通知已標記為已讀' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除通知
router.delete('/:id', auth, async (req, res) => {
  try {
    const notification = await Notification.findOneAndDelete({
      _id: req.params.id,
      user: req.userId
    });
    if (!notification) return res.status(404).json({ message: '通知不存在' });
    res.json({ message: '通知已刪除' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 創建通知（内部使用或其他路由調用）
router.post('/', auth, async (req, res) => {
  try {
    const { title, message, type, link } = req.body;
    const notification = new Notification({
      user: req.userId,
      title,
      message,
      type: type || 'system',
      link
    });
    await notification.save();
    res.status(201).json(notification);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
