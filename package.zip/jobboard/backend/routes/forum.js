const express = require('express');
const jwt = require('jsonwebtoken');
const ForumPost = require('../models/ForumPost');

const router = express.Router();

// 認證中介軟體
const auth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: '未授權' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (error) {
    res.status(401).json({ message: '無效的認證' });
  }
};

// 獲取所有帖子（可選：按標籤過濾）
router.get('/', async (req, res) => {
  try {
    const { tag, search } = req.query;
    let query = {};

    if (tag) {
      query.tags = tag;
    }

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } }
      ];
    }

    const posts = await ForumPost.find(query)
      .populate('author', 'name role')
      .sort({ createdAt: -1 })
      .limit(100);

    res.json(posts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 獲取單個帖子
router.get('/:id', async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id)
      .populate('author', 'name role')
      .populate('comments.author', 'name role');

    if (!post) return res.status(404).json({ message: '帖子不存在' });
    res.json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 創建帖子
router.post('/', auth, async (req, res) => {
  try {
    const { title, content, tags } = req.body;

    const post = new ForumPost({
      title,
      content,
      author: req.userId,
      tags: tags || []
    });

    await post.save();
    await post.populate('author', 'name role');

    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 更新帖子
router.put('/:id', auth, async (req, res) => {
  try {
    const post = await ForumPost.findOne({ _id: req.params.id, author: req.userId });
    if (!post) return res.status(404).json({ message: '帖子不存在或無權限' });

    const { title, content, tags } = req.body;
    if (title) post.title = title;
    if (content) post.content = content;
    if (tags) post.tags = tags;
    post.updatedAt = new Date();

    await post.save();
    await post.populate('author', 'name role');

    res.json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除帖子
router.delete('/:id', auth, async (req, res) => {
  try {
    const post = await ForumPost.findOneAndDelete({ _id: req.params.id, author: req.userId });
    if (!post) return res.status(404).json({ message: '帖子不存在或無權限' });

    res.json({ message: '帖子已刪除' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 點讚/取消點讚
router.post('/:id/like', auth, async (req, res) => {
  try {
    const post = await ForumPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: '帖子不存在' });

    const likeIndex = post.likes.indexOf(req.userId);
    if (likeIndex === -1) {
      // 點讚
      post.likes.push(req.userId);
    } else {
      // 取消點讚
      post.likes.splice(likeIndex, 1);
    }

    await post.save();
    res.json({ likes: post.likes.length, liked: likeIndex === -1 });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 添加評論
router.post('/:id/comments', auth, async (req, res) => {
  try {
    const { content } = req.body;

    const post = await ForumPost.findById(req.params.id);
    if (!post) return res.status(404).json({ message: '帖子不存在' });

    post.comments.push({
      author: req.userId,
      content
    });

    await post.save();
    await post.populate('comments.author', 'name role');

    res.json(post.comments);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除評論
router.delete('/:id/comments/:commentId', auth, async (req, res) => {
  try {
    const post = await ForumPost.findOne({ _id: req.params.id, author: req.userId });
    if (!post) return res.status(404).json({ message: '帖子不存在或無權限' });

    const comment = post.comments.id(req.params.commentId);
    if (!comment) return res.status(404).json({ message: '評論不存在' });

    comment.deleteOne();
    await post.save();

    res.json({ message: '評論已刪除' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 獲取所有標籤
router.get('/meta/tags', async (req, res) => {
  try {
    const tags = await ForumPost.distinct('tags');
    res.json(tags);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
