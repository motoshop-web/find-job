const express = require('express');
const jwt = require('jsonwebtoken');
const Resume = require('../models/Resume');

const router = express.Router();

// 認證中介軟體
const auth = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ message: '未授權' });

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.userId = decoded.id;
    next();
  } catch (error) {
    res.status(401).json({ message: '無效的認證' });
  }
};

// 獲取當前用戶的履歷
router.get('/', auth, async (req, res) => {
  try {
    let resume = await Resume.findOne({ user: req.userId });

    // 如果沒有履歷，創建一個空的
    if (!resume) {
      resume = new Resume({ user: req.userId });
      await resume.save();
    }

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 更新或創建履歷
router.put('/', auth, async (req, res) => {
  try {
    const { name, email, phone, location, summary, experience, education, skills } = req.body;

    const resume = await Resume.findOneAndUpdate(
      { user: req.userId },
      {
        name,
        email,
        phone,
        location,
        summary,
        experience,
        education,
        skills,
        updatedAt: new Date()
      },
      { new: true, upsert: true }
    );

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 添加技能標籤
router.post('/skills', auth, async (req, res) => {
  try {
    const { skill } = req.body;

    const resume = await Resume.findOneAndUpdate(
      { user: req.userId },
      { $addToSet: { skills: skill } },
      { new: true, upsert: true }
    );

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除技能標籤
router.delete('/skills/:skill', auth, async (req, res) => {
  try {
    const resume = await Resume.findOneAndUpdate(
      { user: req.userId },
      { $pull: { skills: req.params.skill } },
      { new: true }
    );

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 添加工作經驗
router.post('/experience', auth, async (req, res) => {
  try {
    const { company, position, period, description } = req.body;

    const resume = await Resume.findOneAndUpdate(
      { user: req.userId },
      {
        $push: {
          experience: { company, position, period, description }
        },
        updatedAt: new Date()
      },
      { new: true, upsert: true }
    );

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除工作經驗
router.delete('/experience/:index', auth, async (req, res) => {
  try {
    const resume = await Resume.findOne({ user: req.userId });
    if (!resume) return res.status(404).json({ message: '履歷不存在' });

    resume.experience.splice(parseInt(req.params.index), 1);
    resume.updatedAt = new Date();
    await resume.save();

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 添加教育背景
router.post('/education', auth, async (req, res) => {
  try {
    const { school, degree, year } = req.body;

    const resume = await Resume.findOneAndUpdate(
      { user: req.userId },
      {
        $push: {
          education: { school, degree, year }
        },
        updatedAt: new Date()
      },
      { new: true, upsert: true }
    );

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// 刪除教育背景
router.delete('/education/:index', auth, async (req, res) => {
  try {
    const resume = await Resume.findOne({ user: req.userId });
    if (!resume) return res.status(404).json({ message: '履歷不存在' });

    resume.education.splice(parseInt(req.params.index), 1);
    resume.updatedAt = new Date();
    await resume.save();

    res.json(resume);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
