const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config();

const app = express();

// CORS 配置
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// JSON 解析
app.use(express.json());

// MongoDB 連接
mongoose.connect(process.env.MONGODB_URI).then(() => console.log('✅ DB connected'));

// 路由
app.use('/api/auth', require('./routes/auth'));
app.use('/api/jobs', require('./routes/jobs'));
app.use('/api/applications', require('./routes/applications'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/resumes', require('./routes/resumes'));
app.use('/api/forum', require('./routes/forum'));

// 測試端點
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Find Job API is running' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
