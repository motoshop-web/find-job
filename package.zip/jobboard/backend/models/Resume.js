const mongoose = require('mongoose');

const resumeSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  name: { type: String },
  email: { type: String },
  phone: { type: String },
  location: { type: String },
  summary: { type: String },
  experience: [{
    company: String,
    position: String,
    period: String,
    description: String
  }],
  education: [{
    school: String,
    degree: String,
    year: String
  }],
  skills: [String],
  updatedAt: { type: Date, default: Date.now }
});

// 確保每個用戶只有一份履歷
resumeSchema.index({ user: 1 }, { unique: true });

module.exports = mongoose.model('Resume', resumeSchema);
