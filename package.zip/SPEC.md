# 求職平台系統 (JobBoard)

## 1. Concept & Vision

一個專業且現代的求職平台，連接求职者与雇主。设计风格采用科技感十足的深色主题，配合亮眼的渐变色强调色，营造专业但不失活力的招聘体验。平台强调简洁的导航与清晰的信息层级，让用户能快速找到所需功能。

## 2. Design Language

### 2.1 Aesthetic Direction
- **风格**: 现代科技感 / Dark Mode Premium
- **参考**: LinkedIn + Glassdoor + Vercel Dashboard

### 2.2 Color Palette
```
Primary:     #6366F1 (Indigo-500)
Secondary:   #8B5CF6 (Violet-500)
Accent:      #10B981 (Emerald-500)
Background:  #0F172A (Slate-900)
Surface:     #1E293B (Slate-800)
Surface Alt: #334155 (Slate-700)
Text Primary:#F8FAFC (Slate-50)
Text Secondary:#94A3B8 (Slate-400)
Border:      #475569 (Slate-600)
Error:       #EF4444 (Red-500)
Warning:     #F59E0B (Amber-500)
Success:     #10B981 (Emerald-500)
```

### 2.3 Typography
- **Primary Font**: Inter (Google Fonts) - 正文、UI元素
- **Display Font**: Plus Jakarta Sans (Google Fonts) - 标题、强调
- **Fallback**: system-ui, -apple-system, sans-serif
- **Scale**: 12px / 14px / 16px / 18px / 24px / 32px / 48px

### 2.4 Spatial System
- **Base Unit**: 4px
- **Spacing Scale**: 4, 8, 12, 16, 24, 32, 48, 64, 96px
- **Border Radius**: 6px (buttons), 12px (cards), 16px (modals), 9999px (pills)

### 2.5 Motion Philosophy
- **Transition Duration**: 150ms (micro), 250ms (standard), 400ms (emphasis)
- **Easing**: cubic-bezier(0.4, 0, 0.2, 1)
- **Hover States**: scale(1.02) + shadow elevation
- **Page Transitions**: fade + subtle slide (transform 10px)

### 2.6 Visual Assets
- **Icons**: Lucide React (consistent stroke width 1.5px)
- **Images**: Unsplash for placeholder job/company images
- **Decorative**: Gradient overlays, subtle grid patterns

## 3. Layout & Structure

### 3.1 Global Layout
```
┌─────────────────────────────────────────────────┐
│  Header (Logo + Nav + User Actions)             │
├─────────────────────────────────────────────────┤
│                                                 │
│  Main Content Area (Dynamic per route)          │
│                                                 │
├─────────────────────────────────────────────────┤
│  Footer (Links + Copyright)                    │
└─────────────────────────────────────────────────┘
```

### 3.2 Navigation Structure

**未登入用戶:**
- 首页 (找工作入口)
- 职位列表
- 论坛
- 登入 / 注册

**求職者:**
- 首页
- 找工作 (职位列表 + 搜索)
- 我的應徵 (追蹤進度)
- 通知中心
- 履歷表管理
- 論壇
- 個人設定

**雇主:**
- 首页
- 發布職缺
- 查看應徵 (候選人列表)
- 論壇
- 個人設定

### 3.3 Responsive Strategy
- **Mobile**: < 640px (单栏布局，底部导航)
- **Tablet**: 640px - 1024px (双栏布局)
- **Desktop**: > 1024px (三栏布局，侧边导航)

## 4. Features & Interactions

### 4.1 身份驗證系統
- **登入**: 邮箱 + 密码
- **註冊**: 邮箱 + 密码 + 角色选择 (求职者/雇主)
- **表单验证**: 实时验证 + 错误提示
- **记住登录状态** (localStorage)

### 4.2 求职者功能

#### 找工作
- 职位列表：卡片式展示，含公司logo、职位名称、薪资范围、地点、发布时间
- 筛选功能：工作类型（全职/兼职/远程）、薪资范围、地点、经验要求
- 搜索：关键词搜索职位
- 收藏职位
- 查看职位详情并投递

#### 通知中心
- 系统通知（投递状态更新）
- 新职位推荐
- 未读标记

#### 履歷表管理
- 创建/编辑履歷表
- 基本信息（姓名、邮箱、电话、地址）
- 工作经历
- 教育背景
- 技能标签
- 简历预览

### 4.3 雇主功能

#### 發布職缺
- 职位名称、描述、要求
- 薪资范围、工作类型、地点
- 技能要求标签
- 预览发布

#### 查看應徵
- 候选人列表（按职位筛选）
- 查看候选人履歷表
- 处理申请（通过/拒绝）
- 发送面试邀请

### 4.4 論壇系統
- 帖子列表：标题、作者、发布时间、点赞数、评论数
- 帖子详情：内容、评论、回复
- 发帖功能（验证用户身份）
- 点赞/点踩

### 4.5 個人設定
- 头像上传
- 基本信息修改
- 密码修改
- 通知偏好

## 5. Component Inventory

### 5.1 Navigation Components
- **Navbar**: Logo + Nav Links + Auth Actions
  - States: logged-out, job-seeker, employer
  - Mobile: hamburger menu with drawer

- **Sidebar**: Vertical nav for dashboard
  - Collapsible with icons only mode

### 5.2 Cards
- **JobCard**: 职位卡片
  - Default: 公司logo + 职位信息
  - Hover: 阴影提升 + 边框高亮
  - Saved: 书签图标填充

- **PostCard**: 论坛帖子卡片
  - Default: 标题 + 摘要 + 作者信息
  - Hover: 背景色变化

### 5.3 Forms
- **Input**: 文本输入框
  - States: default, focus, error, disabled
  - Error message below

- **Select**: 下拉选择
- **Checkbox/Radio**: 选项选择
- **Textarea**: 多行文本
- **FileUpload**: 文件上传（头像/简历）

### 5.4 Buttons
- **Primary**: 渐变背景 (Indigo → Violet)
- **Secondary**: 边框 + 透明背景
- **Ghost**: 无边框，hover显示背景
- **States**: default, hover, active, loading, disabled

### 5.5 Feedback Components
- **Toast**: 通知消息 (success/error/warning/info)
- **Modal**: 模态框
- **Badge**: 状态标签
- **Avatar**: 用户头像

### 5.6 Data Display
- **Table**: 数据表格（应徵列表）
- **Tabs**: 标签页切换
- **Pagination**: 分页器
- **EmptyState**: 空状态提示

## 6. Technical Approach

### 6.1 Technology Stack
- **Framework**: React 18 + Vite
- **Styling**: Tailwind CSS
- **Icons**: Lucide React
- **State**: React Context + useReducer
- **Routing**: React Router v6
- **Forms**: React Hook Form (可选)

### 6.2 Project Structure
```
/src
  /components
    /ui          # 通用UI组件
    /layout      # 布局组件
    /features    # 功能组件
  /pages
    /auth
    /jobs
    /applications
    /notifications
    /resume
    /forum
    /settings
  /context       # React Context
  /hooks         # Custom Hooks
  /utils         # 工具函数
  /data          # Mock 数据
  /styles        # 全局样式
```

### 6.3 Data Management
- **localStorage**: 用户登录状态、收藏职位、通知
- **Mock Data**: 模拟职位列表、论坛帖子、用户数据
- **Context**: AuthContext (用户状态), JobsContext (职位数据), NotificationsContext

### 6.4 Authentication Flow
```
未登入 → 登入页 → 验证 → 角色判断 → 重定向到对应仪表板
未登入 → 注册页 → 填写信息 → 角色选择 → 注册 → 重定向
```

### 6.5 Key Pages
1. **Landing Page** (/)
2. **Login** (/login)
3. **Register** (/register)
4. **Job List** (/jobs)
5. **Job Detail** (/jobs/:id)
6. **Job Seeker Dashboard** (/dashboard)
7. **Employer Dashboard** (/employer)
8. **Post Job** (/employer/post-job)
9. **Applications** (/employer/applications)
10. **Forum** (/forum)
11. **Forum Post** (/forum/:id)
12. **Resume Builder** (/resume)
13. **Notifications** (/notifications)
14. **Settings** (/settings)

## 7. Mock Data Structure

### 7.1 Users
```json
{
  "id": "uuid",
  "email": "string",
  "password": "hashed",
  "role": "job_seeker | employer",
  "name": "string",
  "avatar": "url",
  "createdAt": "date"
}
```

### 7.2 Jobs
```json
{
  "id": "uuid",
  "title": "string",
  "company": "string",
  "companyLogo": "url",
  "location": "string",
  "salary": { "min": 0, "max": 0 },
  "type": "full-time | part-time | remote",
  "description": "string",
  "requirements": ["string"],
  "employerId": "uuid",
  "createdAt": "date"
}
```

### 7.3 Applications
```json
{
  "id": "uuid",
  "jobId": "uuid",
  "userId": "uuid",
  "resume": "object",
  "status": "pending | reviewed | accepted | rejected",
  "appliedAt": "date"
}
```

### 7.4 Forum Posts
```json
{
  "id": "uuid",
  "title": "string",
  "content": "string",
  "author": "object",
  "likes": 0,
  "comments": [],
  "createdAt": "date"
}
```

## 8. Performance Considerations
- 代码分割 (React.lazy + Suspense)
- 图片懒加载
- 虚拟列表（长列表优化）
- 防抖/节流 (搜索输入)